# MARRA — 2ª Edição

Site estático pronto para publicar na Vercel.

## Publicar sem programar
1. Extraia o arquivo ZIP.
2. Entre em https://vercel.com e crie uma conta ou faça login.
3. No painel, escolha **Add New → Project**.
4. Importe a pasta do projeto por meio de um repositório GitHub (ou use o fluxo de deploy por CLI, se preferir).
5. Como é um site HTML estático, não precisa de Build Command. A pasta de saída é a raiz do projeto.
6. Clique em **Deploy**.

## Antes de divulgar
- Confirme o endereço/cidade do Hytti Pub para validar o link do Google Maps.
- Faça um teste de compra e confira se o WhatsApp correto recebe a mensagem.
- A chave Pix cadastrada é o número informado: 85986882730.
- O site não processa nem confirma pagamentos automaticamente: a confirmação é manual após conferir o comprovante.

Data configurada: 15/01/2027 às 22:00 (horário de Brasília).
